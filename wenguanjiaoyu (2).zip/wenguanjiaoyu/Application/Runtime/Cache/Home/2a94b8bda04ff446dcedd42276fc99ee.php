<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>首页</title>
<link href="/wenguanjiaoyu/Public/css/style.css" rel="stylesheet" media="screen">
<link href="/wenguanjiaoyu/Public/css/xuanxiangka.css" type="text/css" rel="stylesheet" />
<link href="/wenguanjiaoyu/Public/css/index.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/m.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/m_web.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/style1.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/style11.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/style3.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/index22.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/wenguanjiaoyu/Public/css/reveal.css">
<link href="/wenguanjiaoyu/Public/css/video-js.min.css" rel="stylesheet" type="text/css">
<script src="/wenguanjiaoyu/Public/js/video.min.js"></script>  
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/xuanxiangka.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/fanye.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/login.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/js.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/jquery.reveal.js"></script>

</head> 
<script type="text/javascript">
    $(function(){
        $("#aFloatTools_Show").click(function(){
            $('#divFloatToolsView').animate({width:'show',opacity:'show'},100,function(){$('#divFloatToolsView').show();});
            $('#aFloatTools_Show').hide();
            $('#aFloatTools_Hide').show();              
        });
        $("#aFloatTools_Hide").click(function(){
            $('#divFloatToolsView').animate({width:'hide', opacity:'hide'},100,function(){$('#divFloatToolsView').hide();});
            $('#aFloatTools_Show').show();
            $('#aFloatTools_Hide').hide();  
        });
    });
</script>
 <script type="text/javascript" src="http://player.youku.com/jsapi">
                        player = new YKU.Player('youkuplayer',{
                        styleid: '0',
                        client_id: '525db6c648861ff2',
                        vid: 'XNTE2NzQyOTA4',
                        show_related: false
                        });
                    </script>  
<style type="text/css">
    html, body { margin: 0; padding: 0; }
    ul.menu { margin: 50px auto 0 auto; }
    p,p a{font-size:12px;color:#666;}
  </style>
<body>
<!--头部-->
<div class="header_line">
  <div class="header_line_1">
  <span>欢迎访问一博沃顿网！</span>
    <ul>
    <?php if(empty($_SESSION['login']['name'])): ?><li><a href="<?php echo U('Login/signup');?>" id="example2">注册</a></li>
    <li>|</li>
    <li><a href="<?php echo U('Login/login');?>" id="example">登录</a></li>
    <?php else: ?>
    <?php echo ($_SESSION['login']['name']); ?>,欢迎您！|<a href="<?php echo U('Login/cancel');?>">注销</a><?php endif; ?>
    </ul>
  </div>
</div>

   <!--登录弹出框-->
   <!-- <div id="LoginBox" class="denglu">
    <img  class="close_btn" id="closeBtn" src="/wenguanjiaoyu/Public/images/tuichu.jpg" style="float: right;" />
        <div class="denglu_content">
            <p class="denglu_p">用户登录</p>
            <span class="denglu_span">—— 使用已注册信息登录 ——</span>
                <div class="login_content_input">
                                    <form id="" method="post" action="/wenguanjiaoyu/index.php/Home/Controller/Login/login" enctype="multipart/form-data">
                                            <input id="" class="user_name" type="text" name="name" value="" placeholder="用户名"/>
                                            <input id="" class="user_pass" type="password" name="password" value="" placeholder="密码"  />
                                            <input id="loginbtn" class="login_button" type="submit" name="login_button" value="登录" />         
                                    </form>
                                             <p>还没有账号？<a href="" id="dianjizhuce_1" class="dianjizhuce_1">点击注册》</a></p>
                </div>
        </div>
    </div>
    <div id="mask"></div> -->
    <!--弹出注册框-->
  <!--   <div class="baoweizhuce">
    <div id="zhuce_box" class="zhucexinxi">
  <img class="close_btn" id="closeBtn_2" src="/wenguanjiaoyu/Public/images/tuichu.jpg" style="float: right;" />
    <div class="zhucexinxi_content">
      <p class="zhucexinxi_p">用户注册</p>
      <span class="zhucexinxi_span">—— 请输入注册信息 ——</span>
        <div class="login_content_input">
                  <form id="" method="post" action="" enctype="multipart/form-data">
                      <input id="" class="user_name" type="text" name="name" value="" placeholder="用户名" />
                      <input id="" class="user_pass" type="password" name="password" value="" placeholder="密码" />
                        <input id="" class="user_pass" type="password" name="repassword" value="" placeholder="确认密码" />
                        <input id="" class="user_name" type="text" name="tel" value="" placeholder="手机号码" />
                        <input id="" class="user_name" type="text" name="email" value="" placeholder="邮箱" />
                        <input id="zhucebtn" class="login_button" type="submit" name="login_button" value="注册" />           
                  </form>
                                     <p>已有账号？<a href="" id="dianjidenglu_1" class="dianjidenglu_1">点击登录》</a></p>
        </div>
    </div>
  </div>
  </div>
<div id="mask_1"></div> -->
	<div class="header_line_icon">
	<img src="/wenguanjiaoyu/Public/images/logo.jpg" />
	<div class="phone_num_div">
	<img src="/wenguanjiaoyu/Public/images/phone_num.png" />&nbsp;
	咨询电话：<?php echo ($info["phone"]); ?>&nbsp;
	<img src="/wenguanjiaoyu/Public/images/phone_num_2.jpg" />
	</div>
			<ul class="menu">				
					<li><a href="<?php echo U('Index/index');?>">首&nbsp; 页</a></li>
					<li><a href="#">教育资讯</a></li>
					<li><a href="#">课程介绍</a></li>
					<li><a href="#">合作联盟</a></li>
					<li><a href="#">父母大课堂</a></li>
					<li><a href="<?php echo U('Video/video');?>" class="shipinzhuanqu">视频专区</a></li>
					<div class="xialakuang2">
					<li>
					<a href="<?php echo U('Lianxi/index');?>" class="shipinzhuanqu">关于我们</a>
			        <li class="taolunqu"><a href="<?php echo U('Messages/message');?>">讨论区</a></li>
			        </div>
			</ul>
</div>
	</div>
<div class="banner_8">
    <div id="full-screen-slider">
        <ul id="slides">
            <li style="background:url('/wenguanjiaoyu/Public/images/banner_center.jpg') no-repeat center top"><a href="#" target="_blank"></a></li>
            <li style="background:url('/wenguanjiaoyu/Public/images/banner_center2.jpg') no-repeat center top"><a href="#" target="_blank"></a></li>
            <li style="background:url('/wenguanjiaoyu/Public/images/banner_center.jpg') no-repeat center top"><a href="#" target="_blank"></a></li>
            <li style="background:url('/wenguanjiaoyu/Public/images/banner_center2.jpg') no-repeat center top"><a href="#" target="_blank"></a></li>
        </ul>
    </div>
</div>
</div>
<div class="content2_index">
<div class="guanyuwomen_1">
<span>ABOUT US</span><P>关于我们</P>
<img src="/wenguanjiaoyu/Public/images/guanyuwomen_index.gif" />
</div>
<div class="content2_index_left">
<!--选项卡开始-->
                <div id="tab">
                         <div class="tabList">
                                  <ul>
                                  <li class="cur"><a href=#><?php echo ($ainfo["title1"]); ?></a></li>
                                  <li><a href=#><?php echo ($ainfo["title2"]); ?></a></li>
                                  <li><a href=#><?php echo ($ainfo["title3"]); ?></a></li>
                                  <li><a href="#"><?php echo ($ainfo["title4"]); ?></a></li>
                                  </ul>
                         </div>
 <!--下面的class=tabcon添加选项卡要切换的内容-->
  <div class="tabCon">
        <div><?php echo ($ainfo["content1"]); ?></div>
        <div><?php echo ($ainfo["content2"]); ?></div>
        <div><?php echo ($ainfo["content3"]); ?></div>
        <div><?php echo ($ainfo["content4"]); ?></div>
 </div>

</div>
</div>
</div>
	<div class="content3_index">
		<div class="content3_index_banner">
			<div class="content3_index_left">
			<div class="tesejiesshao">
			<p>CHARACTERISTIC</p><br />
			<P><?php echo ($tinfo["title"]); ?></P><br />
			///////////////////////////////////////////////////////////////////////////////////////////////////<br /><br />
			<span><?php echo ($tinfo["tese"]); ?></span>
			</div>
		   </div>
	   </div>
	</div>
</div></div></div></div>
<div class="content_index4"><div class="guanyuwomen_1">
		<span style="width:330px;margin-left: 88px;">TEACHERS STRENGTH</span><P>师资力量</P>
		<img src="/wenguanjiaoyu/Public/images/guanyuwomen_index.gif" />
		</div><div class="laoshi_list">
<div class="laoshi_list_one">
<ul>
      <?php if(is_array($tlist)): foreach($tlist as $key=>$val): ?><li>
                	<div class="list_one_1">
                	<img width="226" height="240" src="/wenguanjiaoyu/Uploads/teacher/<?php echo (date("Y-m-d",$val["addtime"])); ?>/<?php echo ($val["photo"]); ?>" />
                	<p><span><?php echo ($val["name"]); ?></span></p>
                	<p><?php echo ($val["zhicheng"]); ?></p><br />
                	<p></p>
                	</div>
                </li><?php endforeach; endif; ?>
            </ul>
</div>
<span class="up"><img src="/wenguanjiaoyu/Public/images/up.gif" /></span>
<span class="down"><img src="/wenguanjiaoyu/Public/images/down.gif" /></span>
</div>
	</div>
</div>
	</div>
		<div class="content_index5">
			<div class="guanyuwomen_1">
				<span style="width:330px;margin-left: 88px;">NEWS</span><P>新闻动态</P>
				<img src="/wenguanjiaoyu/Public/images/guanyuwomen_index.gif" />
			</div>
			<div class="tiaowen"><img src="/wenguanjiaoyu/Public/images/index_1.jpg" /></div>
<div class="content5_ul_left">
    <ul>
      <?php if(is_array($list)): foreach($list as $key=>$val): ?><li>
          	<div class="CONTENT5">
          	<img width="180" height="110" src='/wenguanjiaoyu/Uploads/news/<?php echo (date("Y-m-d",$val["addtime"])); ?>/<?php echo ($val["image"]); ?>' />
              <div class="xinwen_left">
          	<strong><?php echo ($val["title"]); ?></strong><br />
             <?php echo (date("Y-m-d",$val["addtime"])); ?>
          	<br />

          	<span><?php echo $brief = substr($val['content'],0,200); ?></span>
              <a href="<?php echo U('News/news_content?id='.$val[id]);?>" class="MORE MORE_6">MORE>></a>
              </div>
          	</div>
          </li><?php endforeach; endif; ?>  
    </ul>
</div>
<div class="content5_ul_right">
    <ul>
      <?php if(is_array($list1)): foreach($list1 as $key=>$v): ?><li>
          	<div class="CONTENT5_right">
          	<img width="180" height="110" src='/wenguanjiaoyu/Uploads/news/<?php echo (date("Y-m-d",$v["addtime"])); ?>/<?php echo ($v["image"]); ?>' />
               <div class="xinwen_right">
          	<strong><?php echo ($v["title"]); ?></strong><br />
             <?php echo (date("Y-m-d",$v["addtime"])); ?>
          	<br />
          	<span><?php echo $br = substr($v['content'],0,200); ?></span>
          	<a href="#" class="MORE MORE_15">MORE>></a>
              </div>
          	</div>
          </li><?php endforeach; endif; ?>

        <a href="<?php echo U('News/news_list');?>" class="MORE" style="margin-top:750px;margin-left:-130px;font-size:16px;border:none;color: #fff;background:#4dbdcb;">MORE>></a>
    </ul>
	     
</div>		
</div><div style="clear:both;"></div>
        </div>
	</div>
  <div class="content6">
<div class="qx">
<div class="guanyuwomen_1">
                   <span style="width:330px;margin-left: 88px;">VIDEO</span><P>您可以观看的视频</P>
                    <img src="/wenguanjiaoyu/Public/images/guanyuwomen_index2.gif" />
            </div>         
    <div class="cont">
        <div class="qximg">
            <ul>
                <?php if(is_array($vlist)): foreach($vlist as $key=>$vll): ?><li>
                    <div class="video667">
                              <div id="youkuplayer" style="width:380px;height:280px">
                                         <object type="application/x-shockwave-flash" data="<?php echo ($vll["url"]); ?>" width="100%" height="100%" id="youku-player" title="Adobe Flash Player">
                                         <param name="allowFullScreen" value="true">
                                         <param name="allowScriptAccess" value="always">
                                         <param name="movie" value="<?php echo ($vll["url"]); ?>">
                                         <param name="flashvars" value="imglogo=&amp;paid=0&amp;partnerId=525db6c648861ff2&amp;styleid=0">
                                         </object>
                             </div>                         
                   </div> 
                     <a href="#" class="haokoubei"><p><?php echo ($vll["video_name"]); ?></p></a>
                </li><?php endforeach; endif; ?>
            </ul>
        </div>
        <span class="up"><img src="/wenguanjiaoyu/Public/images/up1.gif" width="29" height="38" /></span>
        <span class="down"><img src="/wenguanjiaoyu/Public/images/down2.gif" width="29" height="38" /></span>
  </div>
               <a href="<?php echo U('Video/video_list2');?>" class="MORE MORE_7">MORE>></a>
</div>
<div class="content7">
			
		<div class="content7_2">
        常见问题<a href="<?php echo U('Index/wenda');?>" class="MORE MORE_11">MORE>></a>
        <div class="content7_1_list">
                   <ul>
                          <?php if(is_array($list2)): foreach($list2 as $key=>$vl): ?><li><span class="wen">问</span>&nbsp;&nbsp;<strong><?php echo ($vl["title"]); ?></strong></li><br />
                          
                         <li><span class="da">答</span>&nbsp;<?php echo ($vl["cont"]); ?>&nbsp;</li><?php endforeach; endif; ?>
                  </ul>    
        </div>
	   </div>
     <div class="content7_3">
     咨&nbsp;询
     <div class="content7_1_list_1">
         <form id="form-login" class="biaodan_7" method="post" enctype="multipart/form-data" action="/wenguanjiaoyu/index.php/Home/Index/liuyan">
         姓名：<input id="" class="name" type="text" name="name"  autocomplete="off" value=""><br />
         性别：<input type="radio" name="sex" value="1" />男
               <input type="radio" name="sex" value="0" />女<br />
         电话：<input id="" class="name" type="text" name="tel"  autocomplete="off" value=""><br />
         类别：<select required name="cat" class="selectbox" id="">
                      <option value="" selected>---请选择分类---</option>
                      <?php if(is_array($cat)): foreach($cat as $key=>$vo): ?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["name"]); ?></option><?php endforeach; endif; ?>
               </select><br />
         标题：<input id="" class="name" type="text" name="title" value=""><br />
         内容：<textarea id="" name="con" class="message" type="text"></textarea><br />
              <input type="submit" class="button_bottom" value="提交" />
         </form>         
      </div>
     </div>  
</div>
 <div class="footer">
  <div class="footer_index"><img src="/wenguanjiaoyu/Public/images/logo2.jpg" />
    <div class="erweima_899">
    <img src="/wenguanjiaoyu/Public/images/erweima.jpg" />
    </div>
                            <div class="footer_right">
                            COPYRIGHT @ 2016 WENGUAN.COM ALL RIGHTS RESERVED   一博沃顿  版权所有 <br /><br />地址：呼伦贝尔的一个地方    电话：0470-888888   邮箱：wenguan@126.com <br /><br />
                            蒙ICP备12345678号    技术支持：蓝域科技
                            </div>
 	 </div>
 </div>
<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport"><title>无标题文档</title>
<link href="/wenguanjiaoyu/Public/css/style.css" rel="stylesheet" media="screen">
<link href="/wenguanjiaoyu/Public/css/xuanxiangka.css" type="text/css" rel="stylesheet" />
<link href="/wenguanjiaoyu/Public/css/index.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/xuanxiangka.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/fanye.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/login.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/js.js"></script>
</head>
<body>
	<div class="denglu">
		<div class="denglu_content">
			<p class="denglu_p">用户登录</p>
			<span class="denglu_span">—— 使用已注册信息登录 ——</span>
				<div class="login_content_input">
					<form id="" method="post" action="<?php echo U('Login/login');?>">
							<input id="" class="user_name" type="text" name="name" value="" placeholder="用户名"/>
							<input id="" class="user_pass" type="password" name="password" value="" placeholder="密码"  />
						    <input id="" class="login_button" type="submit" name="login_button" value="登录" />	      
					</form>
	                         <p>还没有账号？<a href="#">点击注册》</a></p>
				</div>
		</div>
	</div>
</body>
</html>
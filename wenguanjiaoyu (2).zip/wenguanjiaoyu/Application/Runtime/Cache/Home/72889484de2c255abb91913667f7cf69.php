<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>首页</title>
<link href="/wenguanjiaoyu/Public/css/style.css" rel="stylesheet" media="screen">
<link href="/wenguanjiaoyu/Public/css/xuanxiangka.css" type="text/css" rel="stylesheet" />
<link href="/wenguanjiaoyu/Public/css/index.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/m.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/m_web.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/style1.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/style11.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/style3.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/index22.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/wenguanjiaoyu/Public/css/reveal.css">
<link href="/wenguanjiaoyu/Public/css/video-js.min.css" rel="stylesheet" type="text/css">
<script src="/wenguanjiaoyu/Public/js/video.min.js"></script>  
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/xuanxiangka.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/fanye.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/login.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/js.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/jquery.reveal.js"></script>

</head> 
<script type="text/javascript">
    $(function(){
        $("#aFloatTools_Show").click(function(){
            $('#divFloatToolsView').animate({width:'show',opacity:'show'},100,function(){$('#divFloatToolsView').show();});
            $('#aFloatTools_Show').hide();
            $('#aFloatTools_Hide').show();              
        });
        $("#aFloatTools_Hide").click(function(){
            $('#divFloatToolsView').animate({width:'hide', opacity:'hide'},100,function(){$('#divFloatToolsView').hide();});
            $('#aFloatTools_Show').show();
            $('#aFloatTools_Hide').hide();  
        });
    });
</script>
 <script type="text/javascript" src="http://player.youku.com/jsapi">
                        player = new YKU.Player('youkuplayer',{
                        styleid: '0',
                        client_id: '525db6c648861ff2',
                        vid: 'XNTE2NzQyOTA4',
                        show_related: false
                        });
                    </script>  
<style type="text/css">
    html, body { margin: 0; padding: 0; }
    ul.menu { margin: 50px auto 0 auto; }
    p,p a{font-size:12px;color:#666;}
  </style>
<body>
<!--头部-->
<div class="header_line">
  <div class="header_line_1">
  <span>欢迎访问一博沃顿网！</span>
    <ul>
    <?php if(empty($_SESSION['login']['name'])): ?><li><a href="<?php echo U('Login/signup');?>" id="example2">注册</a></li>
    <li>|</li>
    <li><a href="<?php echo U('Login/login');?>" id="example">登录</a></li>
    <?php else: ?>
    <?php echo ($_SESSION['login']['name']); ?>,欢迎您！|<a href="<?php echo U('Login/cancel');?>">注销</a><?php endif; ?>
    </ul>
  </div>
</div>

   <!--登录弹出框-->
   <!-- <div id="LoginBox" class="denglu">
    <img  class="close_btn" id="closeBtn" src="/wenguanjiaoyu/Public/images/tuichu.jpg" style="float: right;" />
        <div class="denglu_content">
            <p class="denglu_p">用户登录</p>
            <span class="denglu_span">—— 使用已注册信息登录 ——</span>
                <div class="login_content_input">
                                    <form id="" method="post" action="/wenguanjiaoyu/index.php/Home/Controller/Login/login" enctype="multipart/form-data">
                                            <input id="" class="user_name" type="text" name="name" value="" placeholder="用户名"/>
                                            <input id="" class="user_pass" type="password" name="password" value="" placeholder="密码"  />
                                            <input id="loginbtn" class="login_button" type="submit" name="login_button" value="登录" />         
                                    </form>
                                             <p>还没有账号？<a href="" id="dianjizhuce_1" class="dianjizhuce_1">点击注册》</a></p>
                </div>
        </div>
    </div>
    <div id="mask"></div> -->
    <!--弹出注册框-->
  <!--   <div class="baoweizhuce">
    <div id="zhuce_box" class="zhucexinxi">
  <img class="close_btn" id="closeBtn_2" src="/wenguanjiaoyu/Public/images/tuichu.jpg" style="float: right;" />
    <div class="zhucexinxi_content">
      <p class="zhucexinxi_p">用户注册</p>
      <span class="zhucexinxi_span">—— 请输入注册信息 ——</span>
        <div class="login_content_input">
                  <form id="" method="post" action="" enctype="multipart/form-data">
                      <input id="" class="user_name" type="text" name="name" value="" placeholder="用户名" />
                      <input id="" class="user_pass" type="password" name="password" value="" placeholder="密码" />
                        <input id="" class="user_pass" type="password" name="repassword" value="" placeholder="确认密码" />
                        <input id="" class="user_name" type="text" name="tel" value="" placeholder="手机号码" />
                        <input id="" class="user_name" type="text" name="email" value="" placeholder="邮箱" />
                        <input id="zhucebtn" class="login_button" type="submit" name="login_button" value="注册" />           
                  </form>
                                     <p>已有账号？<a href="" id="dianjidenglu_1" class="dianjidenglu_1">点击登录》</a></p>
        </div>
    </div>
  </div>
  </div>
<div id="mask_1"></div> -->
	<div class="header_line_icon">
	<img src="/wenguanjiaoyu/Public/images/logo.jpg" />
	<div class="phone_num_div">
	<img src="/wenguanjiaoyu/Public/images/phone_num.png" />&nbsp;
	咨询电话：<?php echo ($info["phone"]); ?>&nbsp;
	<img src="/wenguanjiaoyu/Public/images/phone_num_2.jpg" />
	</div>
			<ul class="menu">				
					<li><a href="<?php echo U('Index/index');?>">首&nbsp; 页</a></li>
					<li><a href="#">教育资讯</a></li>
					<li><a href="#">课程介绍</a></li>
					<li><a href="#">合作联盟</a></li>
					<li><a href="#">父母大课堂</a></li>
					<li><a href="<?php echo U('Video/video');?>" class="shipinzhuanqu">视频专区</a></li>
					<div class="xialakuang2">
					<li>
					<a href="<?php echo U('Lianxi/index');?>" class="shipinzhuanqu">关于我们</a>
			        <li class="taolunqu"><a href="<?php echo U('Messages/message');?>">讨论区</a></li>
			        </div>
			</ul>
</div>
	</div>
<div class="banner_video"></div>
<div class="content_news_center">
<div class="xinwenneirong">
<h1><?php echo ($info["title"]); ?></h1>
<p class="time_1"><?php echo (date("Y-m-d",$info["addtime"])); ?><p>
<p><?php echo ($info["content"]); ?></p>
</div>

<div class="news_content_right">
<div class="video_text">					
<strong>最近的文章</strong><br />———<br /><br />
<ul>
 	<?php if(is_array($list)): foreach($list as $key=>$v): ?><li><?php echo ($v["title"]); ?></li><?php endforeach; endif; ?>
</ul>
</div>
</div>

</div>
</div>
 <div class="footer">
  <div class="footer_index"><img src="/wenguanjiaoyu/Public/images/logo2.jpg" />
    <div class="erweima_899">
    <img src="/wenguanjiaoyu/Public/images/erweima.jpg" />
    </div>
                            <div class="footer_right">
                            COPYRIGHT @ 2016 WENGUAN.COM ALL RIGHTS RESERVED   一博沃顿  版权所有 <br /><br />地址：呼伦贝尔的一个地方    电话：0470-888888   邮箱：wenguan@126.com <br /><br />
                            蒙ICP备12345678号    技术支持：蓝域科技
                            </div>
 	 </div>
 </div>
<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>首页</title>
<link href="/wenguanjiaoyu/Public/css/style.css" rel="stylesheet" media="screen">
<link href="/wenguanjiaoyu/Public/css/xuanxiangka.css" type="text/css" rel="stylesheet" />
<link href="/wenguanjiaoyu/Public/css/index.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/m.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/m_web.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/style1.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/style11.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/style3.css" rel="stylesheet" type="text/css" />
<link href="/wenguanjiaoyu/Public/css/index22.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/wenguanjiaoyu/Public/css/reveal.css">
<link href="/wenguanjiaoyu/Public/css/video-js.min.css" rel="stylesheet" type="text/css">
<script src="/wenguanjiaoyu/Public/js/video.min.js"></script>  
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/xuanxiangka.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/fanye.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/login.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/js.js"></script>
<script type="text/javascript" src="/wenguanjiaoyu/Public/js/jquery.reveal.js"></script>

</head> 
<script type="text/javascript">
    $(function(){
        $("#aFloatTools_Show").click(function(){
            $('#divFloatToolsView').animate({width:'show',opacity:'show'},100,function(){$('#divFloatToolsView').show();});
            $('#aFloatTools_Show').hide();
            $('#aFloatTools_Hide').show();              
        });
        $("#aFloatTools_Hide").click(function(){
            $('#divFloatToolsView').animate({width:'hide', opacity:'hide'},100,function(){$('#divFloatToolsView').hide();});
            $('#aFloatTools_Show').show();
            $('#aFloatTools_Hide').hide();  
        });
    });
</script>
 <script type="text/javascript" src="http://player.youku.com/jsapi">
                        player = new YKU.Player('youkuplayer',{
                        styleid: '0',
                        client_id: '525db6c648861ff2',
                        vid: 'XNTE2NzQyOTA4',
                        show_related: false
                        });
                    </script>  
<style type="text/css">
    html, body { margin: 0; padding: 0; }
    ul.menu { margin: 50px auto 0 auto; }
    p,p a{font-size:12px;color:#666;}
  </style>
<body>
<!--头部-->
<div class="header_line">
  <div class="header_line_1">
  <span>欢迎访问一博沃顿网！</span>
    <ul>
    <?php if(empty($_SESSION['login']['name'])): ?><li><a href="<?php echo U('Login/signup');?>" id="example2">注册</a></li>
    <li>|</li>
    <li><a href="<?php echo U('Login/login');?>" id="example">登录</a></li>
    <?php else: ?>
    <?php echo ($_SESSION['login']['name']); ?>,欢迎您！|<a href="<?php echo U('Login/cancel');?>">注销</a><?php endif; ?>
    </ul>
  </div>
</div>

   <!--登录弹出框-->
   <!-- <div id="LoginBox" class="denglu">
    <img  class="close_btn" id="closeBtn" src="/wenguanjiaoyu/Public/images/tuichu.jpg" style="float: right;" />
        <div class="denglu_content">
            <p class="denglu_p">用户登录</p>
            <span class="denglu_span">—— 使用已注册信息登录 ——</span>
                <div class="login_content_input">
                                    <form id="" method="post" action="/wenguanjiaoyu/index.php/Home/Controller/Login/login" enctype="multipart/form-data">
                                            <input id="" class="user_name" type="text" name="name" value="" placeholder="用户名"/>
                                            <input id="" class="user_pass" type="password" name="password" value="" placeholder="密码"  />
                                            <input id="loginbtn" class="login_button" type="submit" name="login_button" value="登录" />         
                                    </form>
                                             <p>还没有账号？<a href="" id="dianjizhuce_1" class="dianjizhuce_1">点击注册》</a></p>
                </div>
        </div>
    </div>
    <div id="mask"></div> -->
    <!--弹出注册框-->
  <!--   <div class="baoweizhuce">
    <div id="zhuce_box" class="zhucexinxi">
  <img class="close_btn" id="closeBtn_2" src="/wenguanjiaoyu/Public/images/tuichu.jpg" style="float: right;" />
    <div class="zhucexinxi_content">
      <p class="zhucexinxi_p">用户注册</p>
      <span class="zhucexinxi_span">—— 请输入注册信息 ——</span>
        <div class="login_content_input">
                  <form id="" method="post" action="" enctype="multipart/form-data">
                      <input id="" class="user_name" type="text" name="name" value="" placeholder="用户名" />
                      <input id="" class="user_pass" type="password" name="password" value="" placeholder="密码" />
                        <input id="" class="user_pass" type="password" name="repassword" value="" placeholder="确认密码" />
                        <input id="" class="user_name" type="text" name="tel" value="" placeholder="手机号码" />
                        <input id="" class="user_name" type="text" name="email" value="" placeholder="邮箱" />
                        <input id="zhucebtn" class="login_button" type="submit" name="login_button" value="注册" />           
                  </form>
                                     <p>已有账号？<a href="" id="dianjidenglu_1" class="dianjidenglu_1">点击登录》</a></p>
        </div>
    </div>
  </div>
  </div>
<div id="mask_1"></div> -->

<div class="account">
		<div class="container">
			<div class="register">
					<div class="register-top-grid">
						<h3>文冠注册</h3>
						<form method="post" action="<?php echo U('Login/signup');?>" enctype="multipart/form-data"> 
						<div class="input">
							<font size="4px">　用户名：</font>
							<input id="a" type="text" name="name" placeholder="3-6位"><font size="3px"></font>
						</div>
						<div class="input">
							<font size="4px">　　邮箱：</font>
							<input id="b" type="text" name="email" placeholder="格式：1234@qq.com"><font size="3px"></font>
						</div>
						<div class="input">
							<font size="4px">联系方式：</font>
							<input id="f" type="text" name="tel" placeholder="手机号码（11位）"><font size="3px"></font>
						</div>
					</div>
					<div class="register-bottom-grid">
						<div class="input">                                                                
							<font size="4px">　　密码：</font>
							<input id="c" type="password" name="password" placeholder="8-16位"><font size="3px"></font>
						</div>
						<div class="input">
							<font size="4px">重复密码：</font>
							<input id="d" type="password" name="password2" placeholder="8-16位"><font size="3px"></font>
						</div>
					</div>
					<div class="register-but">
					   <input type="submit" value="提交" id="e">
					</div>
				</form>
			</div>
	    </div>
	</div>

 <div class="footer">
  <div class="footer_index"><img src="/wenguanjiaoyu/Public/images/logo2.jpg" />
    <div class="erweima_899">
    <img src="/wenguanjiaoyu/Public/images/erweima.jpg" />
    </div>
                            <div class="footer_right">
                            COPYRIGHT @ 2016 WENGUAN.COM ALL RIGHTS RESERVED   一博沃顿  版权所有 <br /><br />地址：呼伦贝尔的一个地方    电话：0470-888888   邮箱：wenguan@126.com <br /><br />
                            蒙ICP备12345678号    技术支持：蓝域科技
                            </div>
 	 </div>
 </div>

<script>
	//默认为空不能注册提交
	var name  = $('#a').val();
	if(name=''){
		document.getElementById("e").onclick=function(event){
		    return false;
		}
	}
	//用户名
	$('#a').blur(function(){
		var name  = $('#a').val();
		var len=name.length;
		$.get('/wenguanjiaoyu/index.php/Home/Login/abc?z=user&name='+name+'&len='+len,function(data){
			if(data == 1){
				$('#a').next().css('color','red').html('用户已被注册！');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}else if(data==2){
				$('#a').next().css('color','red').html('用户名不能为空！');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}else if(data==3){
				$('#a').next().css('color','red').html('长度不合法！');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}else{
				$('#a').next().css('color','#6BB4BA').html('可以注册！');
			}
		})
	})

	//邮箱
	$('#b').blur(function(){
		var email  = $('#b').val();
		$.get('/wenguanjiaoyu/index.php/Home/Login/abc?z=email&email='+email,function(data){
			if(data == 1){
				$('#b').next().css('color','#6BB4BA').html('格式正确！');
			}else if(data==2){
				$('#b').next().html('');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}else{
				$('#b').next().css('color','red').html('格式不正确！');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}
		})
	})

	//联系方式
	$('#f').blur(function(){
		var tel  = $('#f').val();
		$.get('/wenguanjiaoyu/index.php/Home/Login/abc?z=tel&tel='+tel,function(data){
			if(data == 1){
				$('#f').next().css('color','#6BB4BA').html('格式正确！');
			}else if(data==2){
				$('#f').next().html('');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}else{
				$('#f').next().css('color','red').html('格式不正确！');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}
		})
	})

	//密码
	$('#c').blur(function(){
		var pwd  = $('#c').val();
		$.get('/wenguanjiaoyu/index.php/Home/Login/abc?z=pwd1&pwd='+pwd,function(data){
			if(data == 1){
				$('#c').next().css('color','#6BB4BA').html('格式正确！');
			}else if(data == 2){
				$('#c').next().html('');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}else{
				$('#c').next().css('color','red').html('格式不正确！');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}
		})
	})
	$('#d').blur(function(){
		var repwd  = $('#d').val();
		var pwd  = $('#c').val();
		$.get('/wenguanjiaoyu/index.php/Home/Login/abc?z=repwd1&repwd='+repwd+'&pwd='+pwd,function(data){
			if(data == 1){
				$('#d').next().css('color','red').html('与上一次密码不一致！');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}else if(data == 2){
				$('#d').next().html('');
				document.getElementById("e").onclick=function(event){
		            return false;
		        }
			}else{	
				$('#d').next().css('color','#6BB4BA').html('两次密码一致！');
			}
		})
	})
</script>
<?php 
	
	//处理性别的变量调节器函数
	function processSex($num){
		$sex = ['女','男','保密'];
		return $sex[$num];
	}

	//处理问题分类
	function processCat($num1){
		$cat_id = ['咨询','留言','建议'];
		return $cat_id[$num1];
	}

 ?>
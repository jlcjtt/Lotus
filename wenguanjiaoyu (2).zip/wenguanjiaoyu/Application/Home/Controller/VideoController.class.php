<?php
namespace Home\Controller;
use Think\Controller;
class VideoController extends Controller {
	//视频列表
    public function video(){
    	$video = D('Video');

    	$list = $video->select();

        $info = D('Lianxi')->field('phone')->order('id desc')->find();

    	//dump($list);

        $this->assign('list',$list);
    	$this->assign('info',$info);
        $this->display();
    }

    //视频详情页
    public function single(){
    	$video = D('video');

    	$id = $_GET['id'];

    	$sql = "select * from video where id={$id}";
    	$list = $video->query($sql);

    	//dump($list); 

    	//评论列表
    	$sql = "select * from user,comment where user.name=comment.user_name and comment.video_id={$id} order by comment.addtime desc";

    	$ulist = D('Comment')->query($sql);

    	//dump($ulist);

    	//观看权限
    	$name = $_SESSION['login']['name'];

    	$id = $_GET['id'];

    	$orders = D('Orders');

    	$sql = "select * from user,orders where user.name=orders.user_name and orders.video_id={$id} group by user.name";
    	$ol = $orders->query($sql);


    	$oll = $ol[0];

    	//dump($oll);
    	$this->assign('list',$list);
    	$this->assign('oll',$oll);
    	$this->assign('ulist',$ulist);
        $this->display();
    }


    //购买视频
    public function orders(){

    	$video = D('Video');

    	$user_name = $_SESSION['login']['name'];

    	//echo $user_name;

    	$id = $_GET['id'];

    	$info = $video->where("id={$id}")->find();

    	//dump($info);
    	$url = $info['url'];
    	$price = $info['price'];

    	$sql = "INSERT INTO `orders` (`video_id`, `user_name`, `url`, `price`, `able`) VALUES ('{$id}', '{$user_name}', '{$url}', '{$price}', '1')";

    	$in = D('Orders')->execute($sql);

        $this->redirect("Video/single?id=".$id);

    }

   //视频评论
    public function comment(){

    	$comment = D('Comment');

    	$data['content'] = $con = $_POST['content'];
    	
    	$data['addtime'] = time();

    	$data['video_id'] = $id = $_POST['video_id'];

    	$data['user_name'] = $user_name = $_SESSION['login']['name'];


    	//dump($data);

    	$comment->data($data)->add();

        $this->redirect("Video/single?id=".$id);
    }


    //视频列表页
    public function video_list2(){

        $name = $_SESSION['login']['name'];

        $sql = "select * from orders,video where orders.user_name='{$name}' and orders.video_id=video.id";
        $list = D('video')->query($sql);

        // $list = D('Video')->select();
        $this->assign('list',$list);
       // dump($list);
        $this->display();
    }
}
<?php
namespace Home\Controller;
use Think\Controller;
class NewsController extends Controller {
	//新闻详情
	public function news_content(){
		$id = I('get.id');

		$info = D('News')->where("id={$id}")->find();

		$list = D('News')->field('title')->order("id desc")->select();


		$this->assign("info",$info);
		$this->assign("list",$list);
		$this->display();
	}

	//新闻列表
	public function news_list(){
		$list = D('News')->select();

		$this->assign('list',$list);
		$this->display();
	}
}
<?php
namespace Home\Controller;
use Think\Controller;
/**********************************************************/
		//Author:Lotus Bai   CreateTime:2017-1-6
/**********************************************************/
class LoginController extends Controller {
	//登录
    public function login(){
        if(IS_POST){
            $_SESSION['login']['name']=$name=$_POST['name'];
            $_SESSION['login']['password']=$pwd=$_POST['password'];
            $log_time=$_SESSION['login']['log_time']=time();
            $sql="select * from user where name='{$name}' and password='{$pwd}'";
            $nu=D('user')->query($sql);
            $_SESSION['login']['id']=$nu[0]['id'];
            if($nu>0){
                $sql="update user set log_time='$log_time' where id={$nu[0]['id']}";
                D('user')->execute($sql);
                $this->redirect('Index/index');
            }else{     
               	$this->error('账号或密码错误！');
            }
        }else{ 
            $this->display();
        }    
    }


     //注册
     public function signup(){
        if(IS_POST){
            $name=$_POST['name'];
            $email=$_POST['email'];
            $tel=$_POST['tel'];
            $pwd=md5($_POST['password']);
            $repwd=md5($_POST['password2']);
            $_SESSION['login']['reg_time']=$reg_time=$log_time=time();
            
            if($pwd==$repwd){
                $user=D('user');
                $sql="insert into user(name,email,tel,password,reg_time) values('{$name}','{$email}','{$tel}','{$pwd}','{$reg_time}')";
                $user->execute($sql);
                $this->redirect('Login/login');
            }   
        }
        $this->display();
    }

    //ajax 判断注册
    public function abc(){
        $z = I('get.z');
        switch($z){
            case 'user':
                $name = I('get.name');
                $len = I('get.len');
                if($name !== ""){
                    //判断长度
                    if($len>2 && $len<7){
                        $list=D('user')->where("name='{$name}'")->find();
                        if(count($list)>0){
                            echo 1;
                        }else{
                            echo 0;
                        }
                    }else{
                        echo 3;
                    }    
                }else{
                    echo 2;
                }    
                break;
            case 'email':
                $email = I('get.email');
                if($email!==""){
                        $q = preg_match('/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/',$email);
                        echo $q;
                }else{
                    echo 2;
                }
                break;
            case 'tel':
                $tel = I('get.tel');
                if($tel!==""){
                    $t=preg_match('/^1(3|4|5|7|8)\d{9}$/',$tel);
                    echo $t;
                }else{
                    echo 2;
                }
                break;
            case 'pwd1':
                if(I('get.pwd') != ""){
                    $qw=strlen(I('get.pwd'));
                    if($qw>7 && $qw<17){
                        echo 1;
                    }else{
                        echo 0;
                    }
                }else{
                    echo 2;
                }    
                break;
            case 'repwd1':
                if(I('get.repwd') != ""){
                    $as=md5(I('get.repwd'));
                        if(I('get.repwd') != I('get.pwd')){
                            echo 1;
                        }else{
                            echo 0;
                        }
                }else{
                    echo 2;
                }
                break;
        }
    }

    
    //注销
    public function cancel(){
        unset($_SESSION['login']);
        $this->redirect('Index/index');
    }

}
<?php
namespace Home\Controller;
use Think\Controller;
class MessagesController extends Controller {

	public function message(){

		$list = D('Messages')->order('id desc')->select();

		// $sql = "select * from messages m,message_com c where m.id=c.message_id";
		// $list = D('Messages')->query($sql);

		//($list);

        $info = D('Lianxi')->field('phone')->order('id desc')->find();


		$this->assign('list',$list);
		$this->assign('info',$info);

		$this->display();
	}

	//留言详情
	public function message2(){
		$id = $_GET['id'];

		$li = D('Messages')->where("id={$id}")->find();

		$sql = "select * from messages m,message_com c,user u where m.id=c.message_id and m.id={$id} and c.com_user=u.name order by c.addtime desc";

		$list = D('Messages')->query($sql);

		$list1 = D('Message_com')->select();



		$this->assign('list',$list);
		$this->assign('list1',$list1);
		$this->assign('li',$li);

		// dump($list);

		// echo $_SERVER['HTTP_REFERER'];


		$this->display();
	}

	//添加留言
	public function add(){
		if (IS_POST) {
			$data['user_name'] = $_SESSION['login']['name'];
			$data['addtime'] = time();
			$data['title'] = $_POST['title'];
			$data['content'] = $_POST['content'];

			D('Messages')->add($data);
			$this->redirect('Messages/message');
		}
		
	}


	//评论留言
	public function addcom(){
		if (IS_POST) {
			$data['com_user'] = $_SESSION['login']['name'];
			$data['addtime'] = time();
			$data['message_id'] = $_POST['message_id'];
			$data['mess_comm'] = $_POST['mess_comm'];

			//dump($data);

			$result = D('Message_com')->add($data);

			if($result){
			    $this->success('评论成功');
			} else {
			    $this->error('评论失败');
			}
		}
		
	}


}

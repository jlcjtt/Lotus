<?php
namespace Home\Controller;
use Think\Controller;
use Think\Page;
use Think\Model;
class IndexController extends Controller {
    //首页内容
    public function index(){
    	$news = D('News');

		$list = $news->limit(0,3)->select();
		$list1 = $news->limit(3,5)->select();

        $cat = D('Cat')->select();

        $sql = "select * from zixun,cat,huifu where zixun.cat_id=cat.id and zixun.id=huifu.zixun_id order by zixun.addtime desc limit 3";
        $list2 = D('Zixun')->query($sql);
        
        $ainfo = D('About_us')->order('id desc')->find();
        $tinfo = D('tese')->order('id desc')->find();


        $name = $_SESSION['login']['name'];

        $sql = "select * from orders,video where orders.user_name='{$name}' and orders.video_id=video.id limit 5";
        $vlist = D('video')->query($sql);

        $tlist = D('teacher')->select();

        //首页400电话
        $info = D('Lianxi')->field('phone')->order('id desc')->find();
       // dump($info);
        $this->assign('info',$info);

        $this->assign('tlist',$tlist);
		$this->assign('list',$list);
        $this->assign('list1',$list1);
        $this->assign('list2',$list2);
        $this->assign('ainfo',$ainfo);
        $this->assign('tinfo',$tinfo);
        $this->assign('vlist',$vlist);
        $this->assign('cat',$cat);
		$this->display();
    }

    //留言咨询
    public function liuyan(){
    	//$liuyan = D('liuyan');

    	if (IS_POST) {
    		$data['user_name']=$name = $_POST['name'];
    		$data['sex']=$sex = $_POST['sex'];
    		$data['tel']=$tel = $_POST['tel'];
    		$data['cat_id']=$cat_id = $_POST['cat'];
            $data['con']=$con = $_POST['con'];
    		$data['title']=$title = $_POST['title'];
            $data['addtime'] = $addtime = time();


    		//dump($data);

            $list = D('zixun')->add($data);


    		$this->redirect('Index/index');

    	}
    }

    //问答详情页
    public function wenda(){
        $sql = "select count(*) from zixun,huifu where zixun.id=huifu.zixun_id";
        $total = D('Zixun')->query($sql);
        foreach ($total as $val) {
               foreach ($val as $v) {
                    $v;
               }
           }


        $page = new Page($v,3);
        $model = new Model();

        $sql = "select * from zixun,huifu where zixun.id=huifu.zixun_id order by zixun.id desc limit "."$page->firstRow,$page->listRows";
        $list = $model->query($sql);
        

        $info = D('Lianxi')->field('phone')->order('id desc')->find();

       


        //dump($list);

        $pageButton = $page->show();

        $this->assign('list',$list);
        $this->assign('info',$info);
        $this->assign('pageButton',$pageButton);
        $this->display();
    }

}
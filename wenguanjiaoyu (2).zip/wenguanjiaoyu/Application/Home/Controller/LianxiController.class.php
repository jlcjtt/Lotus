<?php
namespace Home\Controller;
use Think\Controller;
class LianxiController extends Controller {
	//关于我们页面
	public function index(){
		$info = D('Lianxi')->order('id desc')->find();
		$this->assign('info',$info);
		$this->display();
	}
}
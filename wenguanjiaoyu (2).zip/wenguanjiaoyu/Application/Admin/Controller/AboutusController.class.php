<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Page;
use Think\Image;
class AboutusController extends Controller {
	public function index(){
		if (IS_POST) {
			$data['title1'] = $_POST['title1'];
			$data['title2'] = $_POST['title2'];
			$data['title3'] = $_POST['title3'];
			$data['title4'] = $_POST['title4'];
			$data['content1'] = $_POST['content1'];
			$data['content2'] = $_POST['content2'];
			$data['content3'] = $_POST['content3'];
			$data['content4'] = $_POST['content4'];

			$res = D('About_us')->add($data);

			if ($res) {
				$this->success('添加成功！');
			}else{
				$this->error('添加失败！');
			}
			
		}

		$this->display();
	}

	//特色介绍
	public function tese(){
		if (IS_POST) {
			$data['title'] = $_POST['title'];
			$data['tese'] = $_POST['tese'];

			$resl = D('Tese')->add($data);

			if ($resl) {
				$this->success('添加成功！');
			}else{
				$this->error('添加失败！');
			}
		}

		$this->display();
	}
}
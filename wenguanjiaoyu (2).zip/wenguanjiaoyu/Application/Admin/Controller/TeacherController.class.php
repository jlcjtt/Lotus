<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Page;
use Think\Image;
class TeacherController extends Controller {
    public function index(){

    	$list = M('Teacher')->select();

    	$this->assign('list',$list);
		$this->display();

		}

	//添加教师信息
	public function add(){
		if (IS_POST) {
			$data['name'] = $_POST['name'];
			$data['jieshao'] = $_POST['jieshao'];
			$data['zhicheng'] = $_POST['zhicheng'];
			$data['addtime'] = time();

			$upload = new \Think\Upload();
	        $upload->maxSize = 3145728 ;
	        $upload->exts = array('jpg', 'gif', 'png', 'jpeg');
	        $upload->savePath = "teacher/"; 

	        $upload->saveRule = 'uniqid';
	        $upload->thumbRemoveOrigin  = true;

	        $image = $upload->upload();

	        //dump($image);
	          
	        foreach($image as $val){ 
	            $path = $val['savepath'];
	           
	        }

	        $data['photo'] = $val['savename'];

	        if (IS_POST) {
	             $teacher = D('Teacher');
	             if (!empty($_POST)) {
	                $_POST['photo'] = $data['photo'];
	               // dump($data);
	                $teacher->add($data);
            		$this->success('新增成功','index');
	         }

		}
	}

}


	//删除教师
	public function ajax(){
		D('Teacher')->delete($_POST['id']);
		$this->redirect('Teacher/index');
	}


	// 重新编辑新闻
	public function edit(){
		$id = $_GET['id'];

		$info = D('Teacher')->where("id={$id}")->find();
		$data['id'] = $tid = $_POST['id'];
		$data['name'] = $_POST['name'];
		$data['jieshao'] = $_POST['jieshao'];
		$data['zhicheng'] = $_POST['zhicheng'];
		$data['addtime'] = time();

		$upload = new \Think\Upload();
        $upload->maxSize = 0 ;
 	   	$upload->exts = array('jpg', 'gif', 'png', 'jpeg');
        
        $upload->savePath = "teacher/"; 

        $upload->saveRule = 'uniqid';
        $upload->thumbRemoveOrigin  = true;

        $image = $upload->upload();

        //dump($image);
          
        foreach($image as $val){ 
            $path = $val['savepath'];
           
        }

      	 $data['photo'] = $val['savename'];


    	 $teacher = D('Teacher');

	     if (!empty($_POST)) {
	        $_POST['photo'] = $data['photo'];
       		$teacher->where("id={$tid}")->save($data);
			$this->redirect('Teacher/index');

	     }

	    // dump($data['image']);
		$this->assign('info',$info);
		$this->display('Teacher/edit');

	}

}
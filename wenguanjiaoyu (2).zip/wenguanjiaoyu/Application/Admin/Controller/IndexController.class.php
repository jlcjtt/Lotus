<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Page;
use Think\Image;
class IndexController extends Controller {
    public function index(){
	
		$this->display();

    }

    //新闻列表
		public function imgtable(){
			$news = D('News');

			$total = $news->count();

			$page = new Page($total,7);
			$pageButton = $page->show();
			$list = $news->limit($page->firstRow.','.$page->listRows)->order('addtime desc')->select();

			$this->assign('list',$list);
			$this->assign('pageButton',$pageButton);
			$this->display();
		}

	//视频列表
		public function vlist(){
			$list = M('video')->order('addtime desc')->select();

			$this->assign('list',$list);

			//dump($list);

			$this->display();
		}

}
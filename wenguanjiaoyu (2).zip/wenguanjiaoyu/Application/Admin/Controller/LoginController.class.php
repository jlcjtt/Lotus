<?php
namespace Admin\Controller;
use Think\Controller;
class LoginController extends Controller {
		//登录
	    public function login(){
		    	if(IS_POST){
					$name = I('post.name');
					$pwd = I('post.password','','md5');

					$map['name'] = $name;
					$map['password'] = $pwd;

					$info = M('User')->where($map)->find();

					//dump($info);

					if ($info['level']>0) {
						$this->error('您没有权限！');
					}
					if(empty($info)){
						$this->error('用户名或密码错误');
					}else{
						session('login',$info);
						$this->redirect('Index/index');
					}

				}else{
					$this->display();
				}
			}

		//退出
		public function loginout(){
			session('login',null);
			$this->redirect('login');
		}

    }
<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Page;
use Think\Image;
class LianxiController extends Controller {
	public function index(){
		$this->display();
	}

//添加联系信息
	public function add(){
		if (IS_POST) {
			$data['address'] = $_POST['address'];
			$data['tel'] = $_POST['tel'];
			$data['email'] = $_POST['email'];
			$data['phone'] = $_POST['phone'];

			$lianxi = D('Lianxi')->add($data);

			$this->success('添加成功！','index');
		}

	}
}
<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Page;
use Think\Image;
class ZixunController extends Controller {
	//用户咨询
	public function index(){
		$list = M('Zixun')->order('id desc')->select();

		$this->assign('list',$list);
		$this->display();
	}
	//回复咨询等
	public function huifu(){
		$id = $_GET['id'];

		$info = M('Zixun')->where("id={$id}")->find();

		$data['zixun_id'] = $_POST['id'];
		$data['cont'] = $_POST['cont'];

		
		if (!empty($_POST)) {
			M('Huifu')->add($data);

			D('Zixun')->where("id={$_POST['id']}")->setField('status','1');

			$this->success('回复成功','index');
		}

		$this->assign('info',$info);
		$this->display();
	}


	//删除咨询
	public function ajax(){
		D('Zixun')->delete($_POST['id']);
		$this->redirect('Zixun/index');
	}

}
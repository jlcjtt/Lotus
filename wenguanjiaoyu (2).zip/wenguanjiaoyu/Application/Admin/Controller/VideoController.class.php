<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Page;
use Think\Image;
use Think\Upload;
class VideoController extends Controller {

		//删除视频
		public function ajax(){

			D('video')->delete($_POST['id']);
			$this->redirect('Index/index');

		}

		//视频添加
		public function add(){
				if (IS_POST) {

				$data['video_name'] = $video_name = $_POST['video_name'];
				$data['author'] = $author = $_POST['author'];
				$data['des'] = $des = $_POST['des'];
				$data['url'] = $url = $_POST['url'];
				$data['price'] = $des = $_POST['price'];
				$data['addtime'] = $addtime = time();

				//dump($_POST);

				$upload = new \Think\Upload();
		        $upload->maxSize = 0 ;
	     	   	 $upload->exts = array('jpg', 'gif', 'png', 'jpeg');
		        
		        $upload->savePath = "video/"; 

		        $upload->saveRule = 'uniqid';
		        $upload->thumbRemoveOrigin  = true;

		        $image = $upload->upload();

		        //dump($image);
		          
		        foreach($image as $val){ 
		            $path = $val['savepath'];
		           
		        }

		       $data['image'] = $val['savename'];

		       if (IS_POST) {
		             $video = D('Video');
		             if (!empty($_POST)) {
		                $_POST['image'] = $data['image'];
		             }

		            // dump($_POST);
		             $video->add($data);
		             $this->redirect('Index/vlist');
		        }
			}
		}



	//重新编辑视频
	public function edit(){
		$id = $_GET['id'];

		$info = D('Video')->where("id={$id}")->find();
		
		$data['id'] = $vid = $_POST['id'];
		$data['video_name'] = $video_name = $_POST['video_name'];
		$data['author'] = $author = $_POST['author'];
		$data['url'] = $url = $_POST['url'];
		$data['des'] = $des = $_POST['des'];
		$data['image'] = $image = $_POST['image'];
		$data['price'] = $price = $_POST['price'];
		$data['addtime'] = $addtime = time();


		$upload = new \Think\Upload();
        $upload->maxSize = 0 ;
 	   	$upload->exts = array('jpg', 'gif', 'png', 'jpeg');
        
        $upload->savePath = "video/"; 

        $upload->saveRule = 'uniqid';
        $upload->thumbRemoveOrigin  = true;

        $image = $upload->upload();

        //dump($image);
          
        foreach($image as $val){ 
            $path = $val['savepath'];
           
        }

      	 $data['image'] = $val['savename'];


    	 $video = D('Video');

	     if (!empty($_POST)) {
	        $_POST['image'] = $data['image'];
       		$video->where("id={$vid}")->save($data);
			$this->redirect('Index/imgtable');

	     }
	    //dump($_POST);
	   // dump($info);

		$this->assign('info',$info);
		$this->display('Index/edit');

	}
}
<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Page;
use Think\Image;
use Think\Upload;
class NewsController extends Controller {
	//添加新闻
	public function news(){

		if (IS_POST) {

			$data['title'] = $title = $_POST['title'];
			$data['author'] = $author = $_POST['author'];
			$data['content'] = $content = $_POST['content'];
			$data['addtime'] = $addtime = time();

			//dump($_POST);

			$upload = new \Think\Upload();
	        $upload->maxSize = 3145728 ;
	        $upload->exts = array('jpg', 'gif', 'png', 'jpeg');
	        $upload->savePath = "news/"; 

	        $upload->saveRule = 'uniqid';
	        $upload->thumbRemoveOrigin  = true;

	        $image = $upload->upload();

	        //dump($image);
	          
	        foreach($image as $val){ 
	            $path = $val['savepath'];
	           
	        }

	       $data['image'] = $val['savename'];

	       if (IS_POST) {
	             $news = D('News');
	             if (!empty($_POST)) {
	                $_POST['image'] = $data['image'];
	             }

	            // dump($_POST);
	             $news->add($data);
	             $this->redirect('Index/imgtable');
	        }
		}
	}

	//删除新闻
	public function ajax(){
		D('News')->delete($_POST['id']);
		$this->redirect('Index/index');
	}


	//重新编辑新闻
	public function edit(){
		$id = $_GET['id'];

		$info = D('News')->where("id={$id}")->find();
		$data['id'] = $nid = $_POST['id'];
		$data['title'] = $title = $_POST['title'];
		$data['author'] = $author = $_POST['author'];
		$data['content'] = $content = $_POST['content'];
		$data['addtime'] = $addtime = time();


		$upload = new \Think\Upload();
        $upload->maxSize = 0 ;
 	   	$upload->exts = array('jpg', 'gif', 'png', 'jpeg');
        
        $upload->savePath = "news/"; 

        $upload->saveRule = 'uniqid';
        $upload->thumbRemoveOrigin  = true;

        $image = $upload->upload();

        //dump($image);
          
        foreach($image as $val){ 
            $path = $val['savepath'];
           
        }

      	 $data['image'] = $val['savename'];


    	 $news = D('News');

	     if (!empty($_POST)) {
	        $_POST['image'] = $data['image'];
       		$news->where("id={$nid}")->save($data);
			$this->redirect('Index/imgtable');

	     }

	    // dump($data['image']);


		$this->assign('info',$info);
		$this->display('Index/form');

	}

		
}
-- 创建数据库
CREATE DATABASE wenguan;
USE wenguan;

-- 1用户表
CREATE TABLE user(
	id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR(50) ,
	password CHAR(32) NOT NULL,
	tel varchar(50) NOT NULL,
  image VARCHAR(255) DEFAULT 'default.jpg',
	email VARCHAR(255)   ,
  level TINYINT UNSIGNED NOT NULL DEFAULT 2,
	addtime INT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2视频表
CREATE TABLE video(
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL , 
    status TINYINT NOT NULL, 	            	
    des VARCHAR(255) NOT NULL ,
    addtime INT NOT NULL,
    liulan INT  	
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


  --3购买表
CREATE TABLE orders(
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,          
    video_id INT NOT NULL,
    user_name Varchar(255) NOT NULL,
    image Varchar(255) NOT NULL,
    url Varchar(255) NOT NULL,
    price TINYINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 4评论表
CREATE TABLE comment(
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,       
    content  Varchar(255),  
    addtime INT NOT NULL,
    video_id INT NOT NULL,
    order_id INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 5新闻表
CREATE TABLE news(
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    title Varchar(255),
    author varchar(255),       
    content  text,  
    addtime INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
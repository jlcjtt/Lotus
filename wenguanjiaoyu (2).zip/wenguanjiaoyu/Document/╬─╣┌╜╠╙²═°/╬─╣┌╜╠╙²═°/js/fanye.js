$(document).ready(function() {
    $(".content_index4 .up").click(function(){
			if(!$(".content_index4 li:first").is(":animated")){
				var ulf = $(".content_index4 li:first")
				var ml = parseInt(ulf.css('margin-left'))
				if(ml==-240){
					$(".content_index4 li").css('margin-left','0')
					$(".content_index4 li:first").appendTo(".content_index4 ul");
					var ulf2 = $(".content_index4 li:first")
					ulf2.animate({marginLeft:-240})
					}else{
					ulf.animate({marginLeft:-240})
					}
				}
			
			
			})
		$(".content_index4 .down").click(function(){
			if(!$(".content_index4 li:first").is(":animated")){
				var ulf = $(".content_index4 li:first")
				var ml = parseInt(ulf.css('margin-left'))
				if(ml==-240){
					ulf.animate({marginLeft:0})
					
					}else{
					$(".content_index4 li:last").css('margin-left','-294px')
					$(".content_index4 li:last").prependTo(".content_index4 ul");
					var ulf2 = $(".content_index4 li:first")
					ulf2.animate({marginLeft:0})
					}
				}
			
			})
});
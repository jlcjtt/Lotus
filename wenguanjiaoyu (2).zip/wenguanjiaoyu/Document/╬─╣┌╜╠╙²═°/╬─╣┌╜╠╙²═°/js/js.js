$(document).ready(function() {
    $(".qx .up").click(function(){
			if(!$(".qximg li:first").is(":animated")){
				var ulf = $(".qximg li:first")
				var ml = parseInt(ulf.css('margin-left'))
				if(ml==-440){
					$(".qximg li").css('margin-left','0')
					$(".qximg li:first").appendTo(".qximg ul");
					var ulf2 = $(".qximg li:first")
					ulf2.animate({marginLeft:-440})
					}else{
					ulf.animate({marginLeft:-440})
					}
				}
			
			
			})
		$(".qx .down").click(function(){
			if(!$(".qximg li:first").is(":animated")){
				var ulf = $(".qximg li:first")
				var ml = parseInt(ulf.css('margin-left'))
				if(ml==-294){
					ulf.animate({marginLeft:0})
					
					}else{
					$(".qximg li:last").css('margin-left','-294px')
					$(".qximg li:last").prependTo(".qximg ul");
					var ulf2 = $(".qximg li:first")
					ulf2.animate({marginLeft:0})
					}
				}
			
			})
});
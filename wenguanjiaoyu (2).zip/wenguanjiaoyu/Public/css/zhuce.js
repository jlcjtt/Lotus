 $(function ($) {
        //弹出注册框
        $("#example2").hover(function () {
            $(this).stop().animate({
                opacity: '1'
            }, 600);
        }, function () {
            $(this).stop().animate({
                opacity: '0.5'
            }, 1000);
        }).on('click', function () {
            $("body").append("<div id='mask_1'></div>");
            $("#mask_1").addClass("mask_1").fadeIn("slow");
            $("#zhuce_box").css({ opacity: '1' });
            $("#zhuce_box").fadeIn("slow");
        });
        //
        //按钮的透明度
        $("#zhucebtn").hover(function () {
            $(this).stop().animate({
                opacity: '1'
            }, 600);
        }, function () {
            $(this).stop().animate({
                opacity: '0.8'
            }, 1000);
        });
        
        //关闭
        $("#closeBtn_2").hover(function () { $(this).css({ color: 'black' }) }, function () { $(this).css({ color: '#999' }) }).on('click', function () {
            $("#zhuce_box").fadeOut("fast");
            $("#mask_1").css({ display: 'none' });
        
    });
         //点击登录关闭注册框
        $("#dianjidenglu_1").hover(function () { $(this).css({ color: 'black' }) }, function () { $(this).css({ color: '#999' }) }).on('click', function () {
            $("#zhuce_box").fadeOut("fast");
            $("#mask_1").css({ display: 'none' });
        });

//并且弹出登录框

 $(".dianjidenglu_1").hover(function () {
            $(this).stop().animate({
                opacity: '1'
            }, 600);
        }, function () {
            $(this).stop().animate({
                opacity: '0.5'
            }, 1000);
        }).on('click', function () {
            $("body").append("<div id='mask'></div>");
            $("#mask").addClass("mask").fadeIn("slow");
            $("#LoginBox").css({ opacity: '1' });
            $("#LoginBox").fadeIn("slow");
        });

        });
 
  $(function ($) {
        //弹出注册框
        $("#example6").hover(function () {
            $(this).stop().animate({
                opacity: '1'
            }, 600);
        }, function () {
            $(this).stop().animate({
                opacity: '0.5'
            }, 1000);
        }).on('click', function () {
            $("body").append("<div id='mask_1'></div>");
            $("#mask_1").addClass("mask_1").fadeIn("slow");
            $("#zhuce_box").css({ opacity: '1' });
            $("#zhuce_box").fadeIn("slow");
        });
        //
        //按钮的透明度
        $("#zhucebtn").hover(function () {
            $(this).stop().animate({
                opacity: '1'
            }, 600);
        }, function () {
            $(this).stop().animate({
                opacity: '0.8'
            }, 1000);
        });
        
        //关闭
        $("#closeBtn_2").hover(function () { $(this).css({ color: 'black' }) }, function () { $(this).css({ color: '#999' }) }).on('click', function () {
            $("#zhuce_box").fadeOut("fast");
            $("#mask_1").css({ display: 'none' });
        
    });
         //点击登录关闭注册框
        $("#dianjidenglu_1").hover(function () { $(this).css({ color: 'black' }) }, function () { $(this).css({ color: '#999' }) }).on('click', function () {
            $("#zhuce_box").fadeOut("fast");
            $("#mask_1").css({ display: 'none' });
        });

//并且弹出登录框

 $(".dianjidenglu_1").hover(function () {
            $(this).stop().animate({
                opacity: '1'
            }, 600);
        }, function () {
            $(this).stop().animate({
                opacity: '0.5'
            }, 1000);
        }).on('click', function () {
            $("body").append("<div id='mask'></div>");
            $("#mask").addClass("mask").fadeIn("slow");
            $("#LoginBox").css({ opacity: '1' });
            $("#LoginBox").fadeIn("slow");
        });

        });
 